def add1(x,y):
    return x+y

print(add1(2,3))

# lambda (x,y): x+y

# print(add1(2,3))

numList = [1, 2, 3, 4, 5, 6, 7, 8, 9]

def mul(a):
    return a*10

resultArr1 = list(map(mul, numList))
print(resultArr1)

resultArr2 = list(map(lambda a: a*10, numList))
print(resultArr2)
