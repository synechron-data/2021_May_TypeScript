var Program = (function () {
    function Program() {
    }
    Program.main = function (arg) {
        console.log("Hello, " + arg);
    };
    return Program;
}());
Program.main("Synechron");
