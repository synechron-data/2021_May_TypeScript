function add1(x, y) {
    return x + y;
}
var add2 = function (x, y) {
    return x + y;
};
var add3;
add3 = function (x, y) {
    return x + y;
};
var add4;
add4 = function (x, y) {
    return x + y;
};
var add5;
add5 = function (x, y) {
    return x + y;
};
var add6;
add6 = function (x, y) { return x + y; };
console.log(add1(2, 3));
console.log(add2(2, 3));
console.log(add3(2, 3));
console.log(add4(2, 3));
console.log(add5(2, 3));
console.log(add6(2, 3));
