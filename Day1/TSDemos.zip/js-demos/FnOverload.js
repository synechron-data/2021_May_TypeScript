function hello_js() {
    console.log("Hello World!");
}

function hello_js(name) {
    console.log("Hello, ", name);
}

hello_js();
hello_js("Synechron");