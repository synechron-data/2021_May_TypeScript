// let j: number;
// j = 20;
// j = 30;

// // const env: string;              // Compile Time Error: 'const' declarations must be initialized.

// const env = "development";
// console.log(env);

// // env = "production";             // Compile Time Error: Cannot assign to 'env' because it is a constant.
// // const env = "production";        // Compile Time Error: Cannot redeclare block-scoped variable 'env'

// if (true) {
//     const env = "production";
//     console.log("Block: ", env);
// }

const obj = { id: 1 };
console.log(obj);

// obj = { name: "Manish" };           // Compile Time Error: Cannot assign to 'obj' because it is a constant.

obj.id = 1000;
console.log(obj);
