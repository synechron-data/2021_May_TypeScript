// var arr1 = [10, 20, 30];

// var arr2 = ["Manish", "Abhijeet"];

// var arr3 = [1, "Abhijeet"];

// var arr4: number[];
// arr4 = [10, 20, 30, 40];

// var arr5: Array<number>;
// arr4 = [10, 20, 30, 40];

// var arr6 = new Array(10);
// console.log(arr6);

// var arr7 = new Array("Manish");
// console.log(arr7);

// var arr8 = Array.of(10);
// console.log(arr8);

// var arr9 = new Array([10, 20, 30]);
// console.log(arr9);

// var arr10 = Array.from([10, 20, 30]);
// console.log(arr10);

// ----------------------------------------------------------------------
// var empList: Array<{ id: number, name: string, city: string }>;
// empList = [
//     { id: 1, name: "Manish", city: "Pune" },
//     { id: 2, name: "Ramakant", city: "Delhi" },
//     { id: 3, name: "Abhijeet", city: "Pune" },
//     { id: 4, name: "Subodh", city: "Mumbai" },
//     { id: 5, name: "Abhishek", city: "Mathura" },
// ];


// ----------------------------------------------------------------------
type Employee = {
    id: number,
    name: string,
    city: string
};

var empList: Array<Employee>;

empList = [
    { id: 1, name: "Manish", city: "Pune" },
    { id: 2, name: "Ramakant", city: "Delhi" },
    { id: 3, name: "Abhijeet", city: "Pune" },
    { id: 4, name: "Subodh", city: "Mumbai" },
    { id: 5, name: "Abhishek", city: "Mathura" },
];

// for (let i = 0; i < empList.length; i++) {
//     console.log(`${i}               ${JSON.stringify(empList[i])}`);
// }

// empList.forEach((item, index, arr) => {
//     console.log(`${index}               ${JSON.stringify(item)}`);
// });

// for(const item of empList){
//     console.log(`${JSON.stringify(item)}`);
// }

// for(const item of empList.entries()){
//     console.log(`${JSON.stringify(item)}`);
// }

// for(const [index, item] of empList.entries()){
//     console.log(`${index}               ${JSON.stringify(item)}`);
// }

// ----------------------------------------------------

// var pune_emps = empList.filter(e => e.city === "Pune");
// console.log(pune_emps);

// var r1 = empList.find(e => e.id === 4);
// console.log(r1);

// var r2 = empList.findIndex(e => e.id === 4);
// console.log(r2);

var r3 = empList.map(e => e.name.toUpperCase());
console.log(r3);