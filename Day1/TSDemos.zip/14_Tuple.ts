// Number Array
var arr1: number[];
arr1 = [10, 20, 30, 40, 50];

// TypeGuard Array
var arr2: (string | number)[];
arr2 = ["Manish", 1];
arr2 = ["Abhijeet", "Pune"];
arr2 = [10, 20, 30, 40, 50];
arr2 = [1, "Manish"];
arr2 = [1, "Abhijeet", "Pune", 411038];

// Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence
let dataRow: [number, string];
dataRow = [1, "Manish"];
// dataRow = ["Abhijeet", "Pune"];
// dataRow = ["Manish", 1];
// dataRow = [10, 20, 30, 40, 50];
// dataRow = [1, "Abhijeet", "Pune", 411038];

function insert(data: [number, string]) {

}

insert([1, "Manish"]);
// insert(["Manish", 1]);
// insert(["Abhijeet", "Pune"]);
// insert([10, 20]);

for (const item of dataRow) {
    console.log(item);
}

let dataRow1: [{ id: number }, string];