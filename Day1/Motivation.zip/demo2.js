console.log("Demo Two");

var Person = (function() {
    function Person(name) {
        this._name = name;
    }
    
    Person.prototype.getName = function () {
        return this._name;
    }
    
    Person.prototype.setname = function (value) {
        this._name = value;
    }

    return Person;
})();

var p1 = new Person("Manish");
console.log(p1.getName());
p1.setname("Abhijeet");
console.log(p1.getName());

var p2 = new Person("Subodh");
console.log(p2.getName());
p2.setname("Ramakant");
console.log(p2.getName());

//  136 Bytes