function multiply(obj: { a, b }) {
    return obj.a * obj.b;
}

function multiplyJS(obj) {
    return obj.a * obj.b;
}

type Shape = {
    a: number,
    b: number
}

function multiplyTS(obj: Shape) {
    return obj.a * obj.b;
}

multiply({ a: "dkasdhkjah", b: true });

multiplyJS(true);

multiplyTS({ a: 10, b: 20 });

function multiplyD({ a, b }) {
    return a * b;
}

multiplyD({ a: 1, b: 20 })

multiplyJS({ a: 1, b: 20, c: 10 })