"use strict";
function getPropValue(obj, key) {
    return obj[key];
}
var person = { id: 1, name: "Manish", city: "Pune" };
var pname = getPropValue(person, "name");
console.log(pname);
//# sourceMappingURL=5_Generics.js.map