"use strict";
var BankManager = (function () {
    function BankManager() {
    }
    BankManager.prototype.approveLoan = function () {
        console.log("Loan Approved...");
    };
    return BankManager;
}());
var AssBankManager = (function () {
    function AssBankManager() {
    }
    AssBankManager.prototype.approveLeave = function () {
        console.log("Leave Approved...");
    };
    return AssBankManager;
}());
var NewBankManager = (function () {
    function NewBankManager() {
    }
    NewBankManager.prototype.approveLoan = function () {
        throw new Error("Method not implemented.");
    };
    NewBankManager.prototype.approveLeave = function () {
        throw new Error("Method not implemented.");
    };
    return NewBankManager;
}());
//# sourceMappingURL=4_ClassAndInterface.js.map