function test(x) {
    console.log("Hello, ", x);
}

test("Manish");
test.call(undefined, "Abhijeet");
test.apply(undefined, ["Ramakant"]);