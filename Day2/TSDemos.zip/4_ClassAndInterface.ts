// interface IPerson {
//     name: string,
//     age: number;
//     greet(message: string): string;
// }

// // class Person implements IPerson {
// //     name: string;
// //     age: number;

// //     constructor(n: string, a: number) {
// //         this.name = n;
// //         this.age = a;
// //     }

// //     greet(message: string): string {
// //         return "Hello";
// //     }
// // }

// class Person implements IPerson {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }
// }

// let p1: IPerson = new Person("Abhijeet", 39);
// let p2: IPerson = new Person("Ramakant", 39);

// console.log(p1.greet("Hi"));
// console.log(p2.greet("Hi"));

// ------------------------------------------------------- Multiple Interface Implementation

// interface IPerson {
//     name: string,
//     age: number;
//     greet(message: string): string;
// }

// interface IEmployee {
//     doWork(): string
// }

// class Person implements IPerson, IEmployee {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning TypeScript";
//     }
// }

// let p1: Person = new Person("Abhijeet", 39);
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());

// // ------------------------------------------------------- Interface Extraction

// interface IPerson {
//     name: string,
//     age: number;
//     greet(message: string): string;
// }

// interface IEmployee {
//     doWork(): string
// }

// interface ICustomer {
//     doShopping(): string;
// }

// class Person implements IPerson, IEmployee, ICustomer {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning TypeScript";
//     }

//     doShopping(): string {
//         return "Let us do it online";
//     }
// }

// // let p1: Person = new Person("Abhijeet", 39);
// // console.log(p1.greet("Hi"));
// // console.log(p1.doWork());
// // console.log(p1.doShopping());

// // Interface Extraction
// let p1: IPerson = new Person("Abhijeet", 39);
// console.log(p1.greet("Hi"));

// let e1: IEmployee = new Person("Abhijeet", 39);
// console.log(e1.doWork());

// let c1: ICustomer = new Person("Abhijeet", 39);
// console.log(c1.doShopping());

// ------------------------------------------------------- Interface extend Other Interface

// interface IPerson {
//     name: string,
//     age: number;
//     greet(message: string): string;
// }

// interface IEmployee extends IPerson {
//     doWork(): string
// }

// interface ICustomer extends IPerson {
//     doShopping(): string;
// }

// class Person implements IPerson, IEmployee, ICustomer {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning TypeScript";
//     }

//     doShopping(): string {
//         return "Let us do it online";
//     }
// }

// let e1: IEmployee = new Person("Ramakant", 39);
// console.log(e1.greet("Hi"));
// console.log(e1.doWork());

// let c1: ICustomer = new Person("Abhijeet", 39);
// console.log(c1.greet("Hi"));
// console.log(c1.doShopping());

// ---------------------------------------------------------------------------- Interface can extend from Class(s)

// Old Codebase
class BankManager {
    approveLoan() {
        console.log("Loan Approved...");
    }
}

class AssBankManager {
    approveLeave() {
        console.log("Leave Approved...");
    }
}

interface INBManager extends BankManager, AssBankManager {}

class NewBankManager implements INBManager {
    approveLoan(): void {
        throw new Error("Method not implemented.");
    }

    approveLeave(): void {
        throw new Error("Method not implemented.");
    }
}
